CANADA INTERACTING WITH DATA — COMPLETE PROJECT

FILES
Canada_Visualization.ipynb   Run this for all code outputs.
map.html                   Folium choropleth (Part 1).
scatter.html               Animated Plotly scatterplot (Part 2).
index.html                 Combined website (Part 3).
donuts.html                Three Plotly donut subplots (Part 4).
Written_Answers.pdf        Written answers; add actual public URL before submitting.
Three original Canada data files are included for reproducibility.

TO RUN
1. Keep the notebook and the three data files together.
2. Install if necessary: pip install pandas geopandas folium plotly notebook
3. Open Canada_Visualization.ipynb in Jupyter and choose Run All.
4. Open index.html in a web browser. Interactive graphs are stored in
   self-contained HTML, so they work without downloading Plotly scripts.

PUBLISHING THE WEBSITE
One easy option is GitHub Pages: upload index.html, map.html, scatter.html,
and donuts.html to the root of a public repository; in repository Settings
> Pages, select Deploy from branch, main, /(root). After deployment, open
the published https://... address and test all three visualizations.
Another option is an HTML hosting service that supports multiple files and
subfolders (for example Netlify Drop); upload all four HTMLs together.

IMPORTANT
The PDF has a clearly labeled placeholder for the PUBLIC WEBPAGE URL.
Replace it with your actual published URL before submission.
Do not submit a local file path as a public URL.

The assignment only explicitly specifies one notebook, one PDF, HTML output
files and a published webpage. It does not request a presentation.
