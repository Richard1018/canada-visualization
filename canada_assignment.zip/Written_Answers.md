# Interacting with Data: Canada — Written Answers

**Public webpage link:** [ADD YOUR REAL PUBLIC WEBSITE URL AFTER PUBLISHING]

## Part 1, Task 2 — Mapping Indigenous Population Composition

**1. Which regions have the largest total Indigenous populations, and how does that differ from the regions with the largest Indigenous percentages?**
Ontario has the largest Indigenous population (470,620), followed by Quebec (350,825) and Alberta (308,005). However, the highest Indigenous shares of total local population are in Nunavut (85.75%), the Northwest Territories (51.12%), and Yukon Territory (20.49%). Manitoba (17.70%) and Saskatchewan (16.94%) also have relatively high shares. This shows why counts and percentages tell different stories: a highly populated province can have more Indigenous residents overall even when Indigenous people make up a smaller share of its population.

**2. Where is each recognized group most concentrated as a percentage of total population?**
First Nations has its largest shares in the Northwest Territories (33.76%) and Yukon Territory (16.90%), followed by Saskatchewan (11.77%) and Manitoba (10.81%). Inuit is particularly concentrated in Nunavut (83.75%) and the Northwest Territories (11.28%). Newfoundland and Labrador (2.05%) also stands out among the provinces. Métis has the largest shares in Manitoba (6.81%), the Northwest Territories (6.09%), and Saskatchewan (5.10%). In general, Inuit is concentrated in the far north, while the higher First Nations and Métis percentages appear in northern and Prairie regions.

## Part 2, Task 2 — Community Belonging and Mental-Health Support

**1. What patterns are visible in community belonging alone? Compare populations and sexes.**
Across plotted regional observations, Non Indigenous results generally have higher belonging percentages than First Nations or Métis: the Both sexes averages are 72.79%, 65.46%, and 67.18%, respectively. For First Nations, the plotted female average (68.76%) is above the male average (63.16%). Non Indigenous female and male averages are similar at 73.02% and 71.94%. Inuit's Nunavut observations have particularly high belonging (83.60% for Both sexes, 86.81% for Females, and 80.56% for Males), but there is only one plotted Inuit observation per sex frame, so a wider Inuit pattern cannot be inferred.

**2. What patterns are visible in mental-health needs met alone? Compare populations and sexes.**
In the available plotted records, women generally have higher percentages reporting that all perceived mental-health needs were met than men. For example, the female and male averages are 29.23% versus 18.06% for First Nations, 30.14% versus 17.83% for Métis, and 20.08% versus 10.53% for Non Indigenous. First Nations and Métis plotted records also tend to have higher values than Non Indigenous records. However, many percentages are missing, especially for some male and Inuit records; these comparisons describe the plotted observations rather than a population-weighted national result.

**3. What is the relationship between belonging and needs met in each sex frame? Discuss outliers and limited Inuit data.**
There is no clear positive association in any frame. The relationships are weakly to moderately negative in the plotted data (approximately -0.28 for Both sexes, -0.42 for Females, and -0.31 for Males). A notable example is the Northwest Territories Métis observation in Both sexes, with high belonging (84.12%) but only 12.20% needs met. Nunavut Inuit women also show high belonging (86.81%) with a low needs-met percentage (15.08%). Ontario Métis women have a comparatively high needs-met value (41.40%) with belonging of 62.69%. The Inuit group contributes just one complete observation per frame, and the male frame has fewer records overall. These limits make broad conclusions unreliable, and the scatterplot cannot establish causation.

## Part 4 — Optional Donut Subplots

Ontario (470,620), Quebec (350,825), and Alberta (308,005) have the three largest Indigenous populations. First Nations forms the largest Indigenous group in all three, but the composition varies. In Quebec, First Nations represents 82.24% of the Indigenous population, compared with 70.66% in Ontario and 61.14% in Alberta. Métis represents a larger share in Alberta (37.49%) than Ontario (28.00%) or Quebec (12.62%). Inuit represents 5.14% in Quebec, compared with 1.34% in Ontario and 1.38% in Alberta. All donut percentages use each province's Indigenous total as the denominator, not its total population.

**Data note:** The figures use only the instructor-provided 2021 Canadian population and community-health files. Blank percentages were not converted to zero. Group and sex averages are simple averages of the plotted regional records, not weighted estimates.
